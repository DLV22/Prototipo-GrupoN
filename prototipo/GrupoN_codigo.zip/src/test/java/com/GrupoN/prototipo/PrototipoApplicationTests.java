package com.GrupoN.prototipo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrototipoApplicationTests {

	@Test
	void contextLoads() {
	}

}
